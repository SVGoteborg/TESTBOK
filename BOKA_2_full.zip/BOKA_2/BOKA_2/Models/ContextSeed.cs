﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOKA_2.Areas.Identity.Models;
using Microsoft.AspNetCore.Identity;

namespace BOKA_2.Models
{
    public class ContextSeed
    {
        public static async Task SeedRolesAsync(RoleManager<IdentityRole> roleManager)
        {
            await roleManager.CreateAsync(new IdentityRole(Models.RoleEdit.Roles.Admin.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Models.RoleEdit.Roles.User.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Models.RoleEdit.Roles.Ekonomi.ToString()));
        }

        public static async Task SeedAdminAsync(UserManager<ApplicationUser> userManager)
        {
            var defaultUser = new ApplicationUser
            {
                UserName = "Admin",
                Email = "christian.otrel@sv.se"
            };

            if (userManager.Users.All(u => u.Id != defaultUser.Id))
            {
                var user = await userManager.FindByEmailAsync(defaultUser.Email);

                if (user == null)
                {
                    await userManager.CreateAsync(defaultUser, "password");
                    await userManager.AddToRoleAsync(defaultUser, Models.RoleEdit.Roles.Admin.ToString());
                    await userManager.AddToRoleAsync(defaultUser, Models.RoleEdit.Roles.User.ToString());
                    await userManager.AddToRoleAsync(defaultUser, Models.RoleEdit.Roles.Ekonomi.ToString());
                }
            }
        }



    }
}
