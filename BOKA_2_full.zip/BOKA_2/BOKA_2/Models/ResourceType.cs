﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOKA_2.Models
{
    public class ResourceType
    {

        public int RTypeId { get; set; }
        public string TypeName { get; set; }
        public string TypeComment { get; set; }
    }
}
