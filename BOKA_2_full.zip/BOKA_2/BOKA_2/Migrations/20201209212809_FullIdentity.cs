﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BOKA_2.Migrations
{
    public partial class FullIdentity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
