﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BOKA_2.Areas.Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
        
    }
}